BL3P exchange official documentation
===

Please access [docs](docs/) for the latest official documentation.

API reference implementations
===

You can find each client reference implementation in:

* [PHP](examples/php/)
* [NodeJs](examples/nodejs/)
* [Java](examples/java/)
* [Go](examples/go/)
