#!/usr/bin/env python2

from distutils.core import setup

setup(name='krakenex',
      version='0.0.5',
      description='kraken.com cryptocurrency exchange API',
      author='Noel Maersk',
      author_email='veox@wemakethings.net',
      url='https://github.com/veox/python2-krakenex',
      packages=['krakenex'],
     )
